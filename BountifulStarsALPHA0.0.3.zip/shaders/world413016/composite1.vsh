#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE1

#include "/program/composite1.glsl"