#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE

#include "/program/composite.glsl"