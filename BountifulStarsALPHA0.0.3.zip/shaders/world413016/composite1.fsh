#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE1

#include "/program/composite1.glsl"