#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DUNA
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"