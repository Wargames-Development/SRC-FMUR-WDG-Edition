#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define DUNA
#define GBUFFERS_WATER
#define GBUFFERS_COLORWHEEL_TRANSLUCENT

#include "/program/gbuffers_water.glsl"