#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE

#include "/program/composite.glsl"