#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE4

#include "/program/composite4.glsl"