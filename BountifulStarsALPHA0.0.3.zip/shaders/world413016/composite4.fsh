#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define DUNA
#define COMPOSITE4

#include "/program/composite4.glsl"