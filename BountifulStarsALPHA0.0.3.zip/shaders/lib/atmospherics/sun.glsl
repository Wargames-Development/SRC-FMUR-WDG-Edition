float SdotU = dot(sunVec, upVec);

#ifdef ORBIT
    float sunFactor = clamp(1.0 + 0.03125, 0.0, 0.0625) / 0.0625;

    float sunVisibility = clamp(1.0 + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
#else
    float sunFactor = SdotU < 0.0 ? clamp(SdotU + 0.375, 0.0, 0.75) / 0.75 : clamp(SdotU + 0.03125, 0.0, 0.0625) / 0.0625;

    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
#endif

float shadowTimeVar1 = max(0.0, clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125 - 0.5) * 2.0;
float shadowTimeVar2 = shadowTimeVar1 * shadowTimeVar1;
float shadowTime = shadowTimeVar2 * shadowTimeVar2;
