#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define VOXY_TRANSLUCENT

#include "/program/voxy_translucent.glsl"