#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE3

#include "/program/composite3.glsl"