#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"