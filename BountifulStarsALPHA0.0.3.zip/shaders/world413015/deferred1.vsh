#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define DEFERRED1

#include "/program/deferred1.glsl"