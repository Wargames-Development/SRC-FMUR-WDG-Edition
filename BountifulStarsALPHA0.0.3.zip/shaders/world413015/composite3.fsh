#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE3

#include "/program/composite3.glsl"