#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_HAND

#include "/program/gbuffers_hand.glsl"