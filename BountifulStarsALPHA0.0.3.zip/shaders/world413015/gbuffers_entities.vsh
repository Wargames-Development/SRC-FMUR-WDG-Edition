#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_ENTITIES

#include "/program/gbuffers_entities.glsl"