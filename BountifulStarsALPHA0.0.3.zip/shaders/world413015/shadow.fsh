#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define SHADOW

#include "/program/shadow.glsl"