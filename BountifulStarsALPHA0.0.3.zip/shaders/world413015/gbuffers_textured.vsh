#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_TEXTURED

#include "/program/gbuffers_textured.glsl"