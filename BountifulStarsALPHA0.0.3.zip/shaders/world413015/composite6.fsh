#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE6

#include "/program/composite6.glsl"