#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_ARMOR_GLINT

#include "/program/gbuffers_armor_glint.glsl"