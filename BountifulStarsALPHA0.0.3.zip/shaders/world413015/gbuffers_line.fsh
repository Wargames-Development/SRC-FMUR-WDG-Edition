#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BASIC
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"