#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"