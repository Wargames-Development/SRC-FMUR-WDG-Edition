#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_DAMAGEDBLOCK
#define GBUFFERS_COLORWHEEL

#include "/program/gbuffers_damagedblock.glsl"
