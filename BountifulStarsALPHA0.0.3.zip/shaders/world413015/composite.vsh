#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE

#include "/program/composite.glsl"