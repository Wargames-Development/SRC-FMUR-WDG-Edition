#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE1

#include "/program/composite1.glsl"