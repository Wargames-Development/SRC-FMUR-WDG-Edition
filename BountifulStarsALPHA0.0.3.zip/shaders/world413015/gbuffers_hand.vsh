#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_HAND

#include "/program/gbuffers_hand.glsl"