#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers_beaconbeam.glsl"