#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"