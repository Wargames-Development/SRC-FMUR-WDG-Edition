#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_TEXTURED

#include "/program/gbuffers_textured.glsl"