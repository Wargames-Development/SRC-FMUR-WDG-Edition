#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING

#include "/program/gbuffers_entities.glsl"