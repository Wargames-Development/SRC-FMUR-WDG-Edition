#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_WATER

#include "/program/gbuffers_water.glsl"