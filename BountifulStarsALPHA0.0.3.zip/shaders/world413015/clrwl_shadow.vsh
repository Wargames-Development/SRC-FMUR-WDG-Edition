#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"