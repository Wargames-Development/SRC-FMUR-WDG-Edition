#version 400 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define SHADOW

#include "/program/shadow.glsl"