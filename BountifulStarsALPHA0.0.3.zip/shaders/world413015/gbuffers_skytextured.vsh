#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"