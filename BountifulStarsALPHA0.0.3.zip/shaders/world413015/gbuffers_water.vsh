#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_WATER

#include "/program/gbuffers_water.glsl"