#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BLOCK

#include "/program/gbuffers_block.glsl"