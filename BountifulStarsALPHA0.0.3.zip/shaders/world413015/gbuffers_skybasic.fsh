#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_SKYBASIC

#include "/program/gbuffers_skybasic.glsl"