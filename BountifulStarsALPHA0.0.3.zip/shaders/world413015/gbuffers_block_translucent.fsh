#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_BLOCK
#define a123

#include "/program/gbuffers_block.glsl"