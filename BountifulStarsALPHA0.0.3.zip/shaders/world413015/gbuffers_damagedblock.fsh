#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_DAMAGEDBLOCK

#include "/program/gbuffers_damagedblock.glsl"