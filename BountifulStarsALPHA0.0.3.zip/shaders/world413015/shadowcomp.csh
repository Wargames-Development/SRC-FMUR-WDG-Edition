#version 430 compatibility

#define COMPUTE_SHADER
#define OVERWORLD
#define MUN
#define SHADOWCOMP

#include "/program/shadowcomp.glsl"