#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define VOXY_OPAQUE

#include "/program/voxy_opaque.glsl"