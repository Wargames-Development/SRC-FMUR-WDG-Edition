#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define COMPOSITE7

#include "/program/composite7.glsl"