#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_TRANSLUCENT

#include "/program/gbuffers_entities.glsl"