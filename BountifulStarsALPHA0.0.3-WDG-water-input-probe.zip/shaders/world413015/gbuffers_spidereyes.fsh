#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_SPIDEREYES

#include "/program/gbuffers_spidereyes.glsl"