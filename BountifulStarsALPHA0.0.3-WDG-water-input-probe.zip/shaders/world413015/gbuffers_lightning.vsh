#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_LIGHTNING

#include "/program/gbuffers_lightning.glsl"