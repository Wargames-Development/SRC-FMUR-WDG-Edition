#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define MUN
#define GBUFFERS_ARMOR_GLINT

#include "/program/gbuffers_armor_glint.glsl"