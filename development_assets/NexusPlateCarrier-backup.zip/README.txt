Archived Nexus Crye G3 plate carrier content. This bundle is no longer installed in the active TaP-Escalation pack.
